## ----pipeline-figure, echo=FALSE, fig.align='center', fig.cap="Data/Science Pipeline"----
knitr::include_graphics("images/tidy1.png")

