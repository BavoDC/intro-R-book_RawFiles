## ----developers-figure, echo=FALSE, fig.align='center'-------------------
knitr::include_graphics("images/NYTimesR2009.jpg")

## ---- eval=FALSE---------------------------------------------------------
## library(ggplot2)
## library(dplyr)

